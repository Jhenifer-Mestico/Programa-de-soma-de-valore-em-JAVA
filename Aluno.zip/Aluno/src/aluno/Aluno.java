/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aluno;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class Aluno {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nome;
        float calculo, n1, n2, n3, n4;
       
    Scanner inputData = new Scanner(System.in);
    System.out.println("Digite o seu nome:");
    nome = inputData.nextLine(); 
    
    System.out.println("Digite primeira nota:");
    n1 = inputData.nextFloat(); 
    
    System.out.println("Digite segunda nota:");
    n2 = inputData.nextFloat(); 
    
    System.out.println("Digite terceira nota:");
    n3 = inputData.nextFloat(); 
    
    System.out.println("Digite quarta nota:");
    n4 = inputData.nextFloat(); 
    
    calculo = n1+n2+n3+n4;
    
    System.out.println(" A soma é:" + calculo);
    }
    
}
